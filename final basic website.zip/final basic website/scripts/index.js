"use strict";
const Arr = [
     {
        id: 123456,
        title: "1",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "2",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "3",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "4",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "5",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "6",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "7",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "8",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "9",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "10",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "11",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "12",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },

    {
        id: 123456,
        title: "13",
        Author: 'Петя Черный',
        description : 'Это приключения мальчика Гарри с фамилией Script. Он изучает удивительный мир JS и погружаеться в филосовский цикл',
        img : "https://bogatyr.club/uploads/posts/2023-03/thumbs/1679420946_bogatyr-club-p-biblioteka-oboi-foni-pinterest-10.jpg",
        price: 10.99,
    },
];

// for (let i = 0; i < Arr.length; i++) {
//     if (i <= 4) {
//         console.log(Arr[i]);
//     } 
// }

// const button = document.querySelector('button');
// let clickCount = 0;
// function Func(params) {  

//     for (let i = 0; i < Arr.length; i++) {
//         if (i <= 4) {
//            const card = document.createElement("div");
//            card.classList.add("art", "article1");
       
//            const title = document.createElement("h2")
//            title.innerText = Arr[i].title;
//            card.appendChild(title);
       
//            const author = document.createElement("h3")
//            author.innerText = Arr[i].Author;
//            card.appendChild(author);
       
//            const description = document.createElement("p")
//            description.innerText = Arr[i].description;
//            card.appendChild(description);
       
//            const price = document.createElement("span")
//            price.innerText = Arr[i].price;
//            card.appendChild(price);
       
//            conta.appendChild(card);
//         } 
//     }

//     if (clickCount == 2) {
//         for (let index = 5; index < Arr.length; index++) {
//             if (index <= 10) {
//                 const card = document.createElement("div");
//             card.classList.add("art", "article1");
        
//             const title = document.createElement("h2")
//             title.innerText = Arr[index].title;
//             card.appendChild(title);
        
//             const author = document.createElement("h3")
//             author.innerText = Arr[index].Author;
//             card.appendChild(author);
        
//             const description = document.createElement("p")
//             description.innerText = Arr[index].description;
//             card.appendChild(description);
        
//             const price = document.createElement("span")
//             price.innerText = Arr[index].price;
//             card.appendChild(price);
        
//             conta.appendChild(card);
            
            
//             } 
//         }
//      }
// }

// button.addEventListener("click", function() {
//   clickCount++;
//   Func(Arr)

     

//      if (clickCount == 3) {
//         for (let inx = 10; inx < Arr.length; inx++) {
//             if (inx <= Arr.length) {
//                 console.log(Arr[inx]);
//             } 
//         }
//      }
// });

// const conta = document.getElementById("Conta");
// conta.classList.add("conteiner-cards", "flex-gap-20");

// const sec = document.getElementById("sec");
// sec.classList.add("cards");




const button = document.querySelector('button');
let clickCount = 0;
const cardsPerClick = 5;

function createCard(data) {
  const card = document.createElement("div");
  card.classList.add("art", "article1");

  const title = document.createElement("h2");
  title.innerText = data.title;
  card.appendChild(title);

  const author = document.createElement("h3");
  author.innerText = data.Author;
  card.appendChild(author);

  const description = document.createElement("p");
  description.innerText = data.description;
  card.appendChild(description);

  const price = document.createElement("span");
  price.innerText = data.price;
  card.appendChild(price);

  return card;
}

button.addEventListener("click", function() {
  const start = clickCount * cardsPerClick;
  const end = Math.min(start + cardsPerClick, Arr.length);

  if (start >= Arr.length) {
    // Достигнут конец массива
    return;
  }

  const conta = document.createElement("div");
  conta.classList.add("conteiner-cards", "flex-gap-10"); // Уменьшаем интервал до 10px

  const sec = document.createElement("div");
  sec.classList.add("cards");

  for (let i = start; i < end; i++) {
    const card = createCard(Arr[i]);
    conta.appendChild(card);
  }

  sec.appendChild(conta);
  document.body.appendChild(sec);

  clickCount++;
});

const conta = document.createElement("div");
conta.id = "Conta";
conta.classList.add("conteiner-cards", "flex-gap-10"); // Уменьшаем интервал до 10px

const sec = document.createElement("div");
